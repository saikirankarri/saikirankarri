require("dotenv").config();

const Backend_API = process.env.REACT_APP_LOCALHOST_BACKEND_API;

module.exports = { Backend_API };
